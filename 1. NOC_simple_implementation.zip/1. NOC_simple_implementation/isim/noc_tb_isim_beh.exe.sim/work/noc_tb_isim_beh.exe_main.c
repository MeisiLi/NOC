/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;

char *IEEE_P_2592010699;
char *STD_STANDARD;
char *IEEE_P_1242562249;


int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    ieee_p_2592010699_init();
    ieee_p_1242562249_init();
    work_a_1271851644_3212880686_init();
    work_a_1991164876_3212880686_init();
    work_a_1555430975_3212880686_init();
    work_a_1641404303_3212880686_init();
    work_a_2522362873_3212880686_init();
    work_a_2872580681_3212880686_init();
    work_a_2166564794_3212880686_init();
    work_a_3158511114_3212880686_init();
    work_a_3429376319_3212880686_init();
    work_a_4043835535_3212880686_init();
    work_a_3675469180_3212880686_init();
    work_a_3866303692_3212880686_init();
    work_a_0301922490_3212880686_init();
    work_a_0748605706_3212880686_init();
    work_a_0109440249_3212880686_init();
    work_a_1004913993_3212880686_init();
    work_a_2464158330_3212880686_init();
    work_a_3091784988_3212880686_init();
    work_a_2801492847_3212880686_init();
    work_a_0919709591_3212880686_init();
    work_a_1399770554_3212880686_init();
    work_a_4112107022_3212880686_init();
    work_a_1722873289_3212880686_init();
    work_a_0737932108_3212880686_init();
    work_a_3698726714_3212880686_init();
    work_a_1645135173_3212880686_init();
    work_a_0681516540_3212880686_init();
    work_a_2372715046_3212880686_init();
    work_a_3935639122_3212880686_init();
    work_a_1289887206_3212880686_init();
    work_a_1157796386_3212880686_init();
    work_a_3816135062_3212880686_init();
    work_a_0793101248_3212880686_init();
    work_a_2265487756_3212880686_init();
    work_a_0586892886_3212880686_init();
    work_a_4244195786_3212880686_init();
    work_a_3636996022_3212880686_init();
    work_a_1493866000_3212880686_init();
    work_a_1031247370_3212880686_init();
    work_a_2600508862_3212880686_init();
    work_a_2528503341_3212880686_init();
    work_a_1499062349_2372691052_init();


    xsi_register_tops("work_a_1499062349_2372691052");

    IEEE_P_2592010699 = xsi_get_engine_memory("ieee_p_2592010699");
    xsi_register_ieee_std_logic_1164(IEEE_P_2592010699);
    STD_STANDARD = xsi_get_engine_memory("std_standard");
    IEEE_P_1242562249 = xsi_get_engine_memory("ieee_p_1242562249");

    return xsi_run_simulation(argc, argv);

}
